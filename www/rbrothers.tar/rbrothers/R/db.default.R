"db.default" <-
function(x, ...)
{
tbr<-dualbrothers(123,x,format="interleaved",window.size=400)
tbr
}

